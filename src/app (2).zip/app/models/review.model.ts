export class Review {
    userName: string;
    rate: number;
    comment: string;
    constructor(
    ) {

    }
}
