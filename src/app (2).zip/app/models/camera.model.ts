export class Camera {
    cameraName: string;
    resolution: string;
    brand: string;
    videoCaptureResolution: string;
    sesnorSize: string;
    opticalZoom: string;
    constructor(
    ) {

    }
}
