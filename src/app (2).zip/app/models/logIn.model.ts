export class LogIn {
    constructor(
        public email: string,
        public pass: string,
    ) {
    }
}
