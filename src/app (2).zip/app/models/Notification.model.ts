export class Notifi {
    constructor(
        public userEmail: string,
        public username: string,
        public id:number,
    ) {
    }
}
