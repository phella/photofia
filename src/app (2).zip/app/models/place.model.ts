export class Place {
    public placeName: string;
    public description: string;
    public rate: number;
    constructor(
    ) {

    }
}
