export class Photographer {
    username: string;
    profilePicture: string;
    bio: string;
    userAddress: string;
    userPhone: string;
    qualifications: string;
    gender: Boolean;
    birthDate: Date;
    rate: number;
    avgPrice: number;
    password: string;
    constructor(
    ) {

    }
}
