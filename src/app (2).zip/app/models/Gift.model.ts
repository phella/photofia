export class Gift {
    public giftName: string;
    public points: number ;
    constructor(
    ) {
    }
}
