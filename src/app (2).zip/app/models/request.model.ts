export class Request {
    constructor(
        public request: string,
        public id: number
    ) {
    }
}
