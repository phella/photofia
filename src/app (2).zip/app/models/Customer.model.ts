export class Customer {
    userName: string;
    profilePicture: string;
    userAddress: string;
    userPhone: string;
    gender: Boolean;
    birthDate: Date;
    points: number;
    constructor(
    ) {

    }
}
