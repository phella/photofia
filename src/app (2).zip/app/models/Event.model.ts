export class Event {
    public id: number;
    public name: string;
    public description: string;
    public eventLocation: string;
    public date: Date;
    constructor(
    ) {
    }
}
