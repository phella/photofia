export class Lens {
    lensName: string;
    focusType: string;
    lensType: string;
    maxFocalRange: string;
    minFocalRange: string;
    maxApartureRange: string;
    constructor(
    ) {

    }
}
